=== Plugin Name ===
Contributors: clarotm
Donate link: https://github.com/amirrezaheydari81
Tags: logo, font,free,display,danafont
Requires at least: 5.0.0
Tested up to: 5.0.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
== Description ==
With this plugin, you can use Dana Persian font on your WordPress site
== Installation ==
Just install it and it will automatically set the font. To disable the font, just turn off the plugin
== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==
= 1.0 =
* Setting and increasing the loading speed of the font

== Upgrade Notice ==
= 1.0 =
Setting and increasing the loading speed of the font